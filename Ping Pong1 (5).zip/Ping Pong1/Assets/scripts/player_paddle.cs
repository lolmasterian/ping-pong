﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player_paddle : MonoBehaviour {
// Use this for initialization
	void Start () {
		
	}

    void Update()
    {
        
        float mousePosInBlocks = (Input.mousePosition.y / Screen.width * 14f) - 7f;

        //Vector3 saves any point in (x,y,z)
        //keeps the y-position fixed
        Vector3 paddlePosition = new Vector3(20f, this.transform.position.x, 20);
        //sets the position of the paddle(this) to 
        // the paddlePosition
        //lim8it the movement of the mouse -6.5f to 6.5f in x asix
        paddlePosition.y = Mathf.Clamp(mousePosInBlocks, -15f, 15f);


        this.transform.position = paddlePosition;


    }
}