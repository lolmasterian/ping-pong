﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class objectmove : MonoBehaviour {

    private Vector3 posA;

    private Vector3 posB;

    private Vector3 nexPos;

    [SerializeField]
    private float speed;
    [SerializeField]
    private Transform childtransform;
    [SerializeField]
    private Transform transformb;


	void Start () {
        posA = childtransform.localPosition;
        posB = transformb.localPosition;
        nexPos = posB;
	}
	
	// Update is called once per frame
	void Update () {

        Move();
	}
    private void Move()
    {
        childtransform.localPosition = Vector3.MoveTowards(childtransform.transform.localPosition, nexPos, speed * Time.deltaTime);
        if (Vector3.Distance(childtransform.localPosition, nexPos) <= 0.1)
        {
            ChangeDestination();
        }
    }
    private void ChangeDestination()
    {
        Vector3 newPos = default(Vector3);
        nexPos = newPos != posA ? posA : posB;
    }
}
