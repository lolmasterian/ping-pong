﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class levelmanager : MonoBehaviour {

	public void LoadLevel(string assigment)
    {
        print("Loading level" + assigment);
        //loads the scene named levelname
        SceneManager.LoadScene(assigment);
    }
    public void LoadNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    void Start()
    {
        
    }
    public void QuitGame()
    {

        UnityEditor.EditorApplication.isPlaying = false;

        Application.Quit();
    }

}
